package com.cognizant;

import org.junit.jupiter.api.Test;

import org.springframework.boot.test.context.SpringBootTest;

  //Test class for AuditWebPortalApplication
@SpringBootTest
class AuditWebPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
